// Crea un objeto Howl para el audio
var miAudio = new Howl({
    src: ['/Assets/duranduran.mp3'], // Ruta completa del archivo de audio
    autoplay: false, // No reproducir automáticamente al cargar la página
    loop: false, // No reproducir en bucle
    volume: 1.0 // Volumen del audio (0 a 1)
  });
  
  // Obtiene una referencia al botón de imagen por su ID
  var botonFotoplay = document.getElementById('fotoplay');
  
  // Variable para realizar un seguimiento del estado de reproducción
  var estaReproduciendo = false;
  
  // Agrega un evento click al botón de imagen para controlar la reproducción/pausa
  botonFotoplay.addEventListener('click', function() {
      if (estaReproduciendo) {
          miAudio.pause(); // Pausa el audio si está reproduciéndose
          botonFotoplay.setAttribute('src', '/Assets/adelante.png'); // Cambia la imagen a "Reproducir"
          estaReproduciendo = false;
      } else {
          miAudio.play(); // Reproduce el audio si está pausado
          botonFotoplay.setAttribute('src', '/Assets/pause.png'); // Cambia la imagen a "Pausar"
          estaReproduciendo = true;
      }
  });
  
  // Evento para detectar cuando se termina la reproducción
  miAudio.on('end', function() {
      botonFotoplay.setAttribute('src', '/Assets/adelante.png'); // Cambia la imagen a "Reproducir" cuando el audio finaliza
      estaReproduciendo = false;
  });
  